package uz.akfagroup.runner.ui.main.progress.models

import android.view.View
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.items.AbstractItem
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.ItemGoalInfoBinding
import uz.akfagroup.runner.utils.getWidgetBitmapCustom

data class GoalInfoData(
    val id: Int,
    val goal: Int? = null,
    val result: Int? = null,
    val month: String? = null,
    val date: String? = null,
) : AbstractItem<GoalInfoData.GoalInfoViewHolder>() {

    override var identifier: Long
        get() = id.toLong()
        set(value) {}

    inner class GoalInfoViewHolder(itemView: View) :
        FastAdapter.ViewHolder<GoalInfoData>(itemView) {
        override fun bindView(item: GoalInfoData, payloads: List<Any>) {
            val binding = ItemGoalInfoBinding.bind(itemView)

            val bitmap = getWidgetBitmapCustom(itemView.context, 7)
            binding.arcProgress.setImageBitmap(bitmap)

        }

        override fun unbindView(item: GoalInfoData) {

        }

    }

    override val type: Int
        get() = 0
    override val layoutRes: Int
        get() = R.layout.item_goal_info

    override fun getViewHolder(v: View): GoalInfoViewHolder = GoalInfoViewHolder(v)


}
