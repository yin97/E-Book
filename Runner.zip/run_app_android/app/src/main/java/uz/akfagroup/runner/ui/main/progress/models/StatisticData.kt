package uz.akfagroup.runner.ui.main.progress.models

import android.os.Build
import android.view.View
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.items.AbstractItem
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.ItemStatisticProgressBinding

data class StatisticData(
    val id: Int,
    val day: String? = null,
    val progress: Int? = null,
) : AbstractItem<StatisticData.StatisticViewHolder>() {


    override var identifier: Long
        get() = id.toLong()
        set(value) {}

    inner class StatisticViewHolder(itemView: View) :
        FastAdapter.ViewHolder<StatisticData>(itemView) {
        override fun bindView(item: StatisticData, payloads: List<Any>) {
            val binding = ItemStatisticProgressBinding.bind(itemView)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                binding.vprogressbar.setProgress(item.progress ?: 0, true)
            } else {
                binding.vprogressbar.progress = item.progress ?: 0
            }

            binding.tvDay.text = item.day
        }

        override fun unbindView(item: StatisticData) {

        }

    }

    override val type: Int
        get() = 0
    override val layoutRes: Int
        get() = R.layout.item_statistic_progress

    override fun getViewHolder(v: View): StatisticViewHolder = StatisticViewHolder(v)
}