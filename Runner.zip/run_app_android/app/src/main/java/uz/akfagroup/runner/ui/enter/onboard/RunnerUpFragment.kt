package uz.akfagroup.runner.ui.enter.onboard

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentRunnerUpBinding

class RunnerUpFragment : Fragment() {

    private lateinit var binding: FragmentRunnerUpBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRunnerUpBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.runner_to_save) }
        binding.toLogin.setOnClickListener { findNavController().navigate(R.id.runner_to_login) }

        return binding.root
    }

}