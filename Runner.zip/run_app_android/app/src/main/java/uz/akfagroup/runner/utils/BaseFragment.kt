package uz.akfagroup.runner.utils

import androidx.fragment.app.Fragment

open class BaseFragment:Fragment() {



}