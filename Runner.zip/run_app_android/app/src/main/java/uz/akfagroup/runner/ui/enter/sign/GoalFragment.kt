package uz.akfagroup.runner.ui.enter.sign

import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.NumberPicker
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.OnboardActivity
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentGoalBinding
import uz.akfagroup.runner.ui.main.MainActivity


class GoalFragment : Fragment() {

    private lateinit var binding: FragmentGoalBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentGoalBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener {
            val intent = Intent(requireContext(), MainActivity::class.java)
            intent.putExtra("start_main", "start")
            startActivity(intent)
            requireActivity().finish()
        }

        binding.appBarNew.isVisible = requireActivity() is OnboardActivity
        binding.appBarEdit.isVisible = requireActivity() is MainActivity
        binding.btnButton.isVisible = requireActivity() is OnboardActivity

        binding.icClose.setOnClickListener {
            findNavController().popBackStack()
        }

        binding.tvSaveGoal.setOnClickListener {
            findNavController().popBackStack()
        }

        binding.tvRun.setOnClickListener { chooseSport(true) }
        binding.tvWalking.setOnClickListener { chooseSport(false) }

        binding.tvDay.setOnClickListener { choosePeriod(1) }
        binding.tvWeek.setOnClickListener { choosePeriod(2) }
        binding.tvMonth.setOnClickListener { choosePeriod(3) }
        binding.tvYear.setOnClickListener { choosePeriod(4) }
        binding.tvCustom.setOnClickListener { choosePeriod(5); showDatePicker() }

        binding.tvDistance.setOnClickListener { chooseGoal(true);showPicker(true) }
        binding.tvStep.setOnClickListener { chooseGoal(false);showPicker(false) }

        return binding.root
    }

    private fun showDatePicker() {
        val datePickerDialog =
            DatePickerDialog(requireContext(), R.style.MyAppTheme, null, 2022, 6, 1)
        datePickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "СОХРАНИТЬ") { dialog, which ->
            Log.e("TAG", "showDatePicker: $which -> $dialog")
        }
        datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "ОТМЕНИТЬ") { dialog, which ->
            Log.e("TAG", "showDatePicker: $which -> $dialog")
        }
        datePickerDialog.show()
    }

    private fun chooseSport(i: Boolean) {
        if (i) {
            binding.cvRun.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.main
                )
            )
            binding.cvWalking.setCardBackgroundColor(Color.parseColor("#334155"))
            binding.tvRun.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.tvWalking.setTextColor(Color.parseColor("#334155"))
        } else {
            binding.cvWalking.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.main
                )
            )
            binding.cvRun.setCardBackgroundColor(Color.parseColor("#334155"))
            binding.tvWalking.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.tvRun.setTextColor(Color.parseColor("#334155"))
        }
    }

    private fun choosePeriod(i: Int) {
        binding.tvDay.setTextColor(Color.parseColor("#334155"))
        binding.cvDay.setCardBackgroundColor(Color.parseColor("#334155"))
        binding.tvWeek.setTextColor(Color.parseColor("#334155"))
        binding.cvWeek.setCardBackgroundColor(Color.parseColor("#334155"))
        binding.tvMonth.setTextColor(Color.parseColor("#334155"))
        binding.cvMonth.setCardBackgroundColor(Color.parseColor("#334155"))
        binding.tvYear.setTextColor(Color.parseColor("#334155"))
        binding.cvYear.setCardBackgroundColor(Color.parseColor("#334155"))
        binding.tvCustom.setTextColor(Color.parseColor("#334155"))
        binding.cvCustom.setCardBackgroundColor(Color.parseColor("#334155"))

        when (i) {
            1 -> {
                binding.tvDay.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.cvDay.setCardBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
            }
            2 -> {
                binding.tvWeek.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.cvWeek.setCardBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
            }
            3 -> {
                binding.tvMonth.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.cvMonth.setCardBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
            }
            4 -> {
                binding.tvYear.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.cvYear.setCardBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
            }
            else -> {
                binding.tvCustom.setTextColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
                binding.cvCustom.setCardBackgroundColor(
                    ContextCompat.getColor(
                        requireContext(),
                        R.color.main
                    )
                )
            }
        }

    }

    private fun chooseGoal(i: Boolean) {
        if (i) {
            binding.cvDistance.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.main
                )
            )
            binding.cvStep.setCardBackgroundColor(Color.parseColor("#334155"))
            binding.tvDistance.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.tvStep.setTextColor(Color.parseColor("#334155"))
        } else {
            binding.cvStep.setCardBackgroundColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.main
                )
            )
            binding.cvDistance.setCardBackgroundColor(Color.parseColor("#334155"))
            binding.tvStep.setTextColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.tvDistance.setTextColor(Color.parseColor("#334155"))
        }
    }

    private fun showPicker(isDistance: Boolean) {
        val dialog: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        val inflater = this.layoutInflater
        val dialogView: View = inflater.inflate(R.layout.number_picker_dialog, null)
        dialog.setTitle("ВИБРАТЬ ДИСТАНЦИЮ")
        dialog.setView(dialogView)
        val numberPicker = dialogView.findViewById<View>(R.id.dialog_number_picker) as NumberPicker
        val tvDimension = dialogView.findViewById<View>(R.id.tv_dimension) as TextView
        numberPicker.maxValue = 50
        numberPicker.minValue = 0
        numberPicker.wrapSelectorWheel = false
        numberPicker.setOnValueChangedListener { picker, old, new ->
            Log.e(
                "TAG",
                "showPicker: old = $old, new = $new, and picker = $picker"
            )
        }
        val numberPicker2 =
            dialogView.findViewById<View>(R.id.dialog_number_picker2) as NumberPicker
        if (isDistance) {
            val meters =
                arrayOf("000", "100", "200", "300", "400", "500", "600", "700", "800", "900")
            numberPicker2.displayedValues = meters
            numberPicker2.maxValue = meters.size - 1
            numberPicker2.minValue = 0
        } else {
            numberPicker2.maxValue = 99
            numberPicker2.minValue = 0
            tvDimension.text = "см"
        }
        dialog.setPositiveButton("СОХРАНИТЬ") { _, i ->
            Log.e(
                "TAG",
                "onClick: $i va " + numberPicker.value
            )
        }
        dialog.setNegativeButton("ОТМЕНИТЬ") { _, i -> Log.e("TAG", "showPicker: $i") }
        val alertDialog: AlertDialog = dialog.create()
        alertDialog.show()
    }

}