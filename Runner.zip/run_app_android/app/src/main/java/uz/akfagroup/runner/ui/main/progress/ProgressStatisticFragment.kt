package uz.akfagroup.runner.ui.main.progress

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.adapters.ItemAdapter
import com.mikepenz.fastadapter.select.getSelectExtension
import uz.akfagroup.runner.databinding.FragmentProgressStatisticBinding
import uz.akfagroup.runner.ui.main.progress.models.PeriodData

class ProgressStatisticFragment : Fragment() {

    private var _binding: FragmentProgressStatisticBinding? = null
    private val binding get() = _binding!!

    private val itemAdapter = ItemAdapter<PeriodData>()
    private var fastAdapter = FastAdapter.with(itemAdapter)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProgressStatisticBinding.inflate(inflater, container, false)

        val selectExtension = fastAdapter.getSelectExtension()
        selectExtension.isSelectable = true

        binding.periodList.layoutManager =
            LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        binding.periodList.adapter = fastAdapter

        binding.icBack.setOnClickListener {
            findNavController().popBackStack()
        }

        itemAdapter.clear()
        itemAdapter.add(PeriodData(0, "День"))
        itemAdapter.add(PeriodData(1, "Неделя"))
        itemAdapter.add(PeriodData(2, "Месяц"))
        itemAdapter.add(PeriodData(3, "Год"))

        return binding.root
    }

}