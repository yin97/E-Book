package uz.akfagroup.runner.ui.main.progress.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.GenericItem
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.LayoutMessageHeaderBinding
import uz.akfagroup.runner.ui.main.progress.models.TrainingData


class StickyHeaderAdapter<Item : GenericItem>() : RecyclerView.Adapter<ViewHolder>(),
    StickyRecyclerHeadersAdapter<ViewHolder> {

    var fastAdapter: FastAdapter<Item>? = null
        private set

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val fastAdapter =
            this.fastAdapter ?: throw RuntimeException("A adapter needs to be wrapped")
        return fastAdapter.onCreateViewHolder(parent, viewType)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
        payloads: List<Any>
    ) {
        fastAdapter?.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        fastAdapter?.onBindViewHolder(holder, position)
    }

    override fun getItemCount(): Int = fastAdapter?.itemCount ?: 0

    override fun getHeaderId(position: Int): Long {
        return when (val item = getItem(position)) {
            is TrainingData -> item.identifier
            else -> -1
        }
    }

    fun getItem(position: Int): Item? = fastAdapter?.getItem(position)


    override fun onCreateHeaderViewHolder(parent: ViewGroup): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_message_header, parent, false)
        return object : ViewHolder(view) {}
    }

    override fun onBindHeaderViewHolder(holder: ViewHolder, position: Int) {
        val binding = LayoutMessageHeaderBinding.bind(holder.itemView)
        Log.d("TAGHEADER", "onBindHeaderViewHolder: $position")
        binding.textMonth.text = when (val item = getItem(position)) {
            is TrainingData -> item.date
            else -> ""
        }
    }

    fun wrap(fastAdapter: FastAdapter<Item>): StickyHeaderAdapter<Item> {
        this.fastAdapter = fastAdapter
        return this
    }

    override fun registerAdapterDataObserver(observer: RecyclerView.AdapterDataObserver) {
        super.registerAdapterDataObserver(observer)
        fastAdapter?.registerAdapterDataObserver(observer)
    }

    override fun unregisterAdapterDataObserver(observer: RecyclerView.AdapterDataObserver) {
        super.unregisterAdapterDataObserver(observer)
        fastAdapter?.unregisterAdapterDataObserver(observer)
    }

    override fun getItemViewType(position: Int): Int = fastAdapter?.getItemViewType(position) ?: 0


    override fun getItemId(position: Int): Long = fastAdapter?.getItemId(position) ?: 0

    override fun setHasStableIds(hasStableIds: Boolean) {
        fastAdapter?.setHasStableIds(hasStableIds)
    }

    override fun onViewRecycled(holder: ViewHolder) {
        fastAdapter?.onViewRecycled(holder)
    }

    override fun onFailedToRecycleView(holder: ViewHolder): Boolean {
        return fastAdapter?.onFailedToRecycleView(holder) ?: false
    }

    override fun onViewDetachedFromWindow(holder: ViewHolder) {
        fastAdapter?.onViewDetachedFromWindow(holder)
    }

    override fun onViewAttachedToWindow(holder: ViewHolder) {
        fastAdapter?.onViewAttachedToWindow(holder)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        fastAdapter?.onAttachedToRecyclerView(recyclerView)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        fastAdapter?.onDetachedFromRecyclerView(recyclerView)
    }

}