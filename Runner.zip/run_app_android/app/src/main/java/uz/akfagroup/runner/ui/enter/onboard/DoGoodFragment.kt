package uz.akfagroup.runner.ui.enter.onboard

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentDoGoodBinding

class DoGoodFragment : Fragment() {

    private lateinit var binding: FragmentDoGoodBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDoGoodBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.good_to_sign) }

        binding.skip.setOnClickListener { findNavController().navigate(R.id.signUpFragment) }

        return binding.root
    }

}