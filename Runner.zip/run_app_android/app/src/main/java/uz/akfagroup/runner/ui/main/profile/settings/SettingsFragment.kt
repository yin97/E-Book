package uz.akfagroup.runner.ui.main.profile.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private var isAbout = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        binding.back.setOnClickListener { findNavController().popBackStack() }

        binding.toEditPassword.setOnClickListener { findNavController().navigate(R.id.settings_to_editPassword) }
        binding.toAbout.setOnClickListener {
            if (isAbout) binding.tvAbout.visibility = View.GONE
            else binding.tvAbout.visibility = View.VISIBLE
            isAbout = !isAbout
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}