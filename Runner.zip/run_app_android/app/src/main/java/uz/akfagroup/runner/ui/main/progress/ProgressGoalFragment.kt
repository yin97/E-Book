package uz.akfagroup.runner.ui.main.progress

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.adapters.ItemAdapter
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentProgressGoalBinding
import uz.akfagroup.runner.ui.main.progress.models.GoalInfoData
import uz.akfagroup.runner.utils.getWidgetBitmapCustom


class ProgressGoalFragment : Fragment() {

    private var _binding: FragmentProgressGoalBinding? = null
    private val binding get() = _binding!!
    private val itemAdapter = ItemAdapter<GoalInfoData>()
    private val fastAdapter = FastAdapter.with(itemAdapter)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProgressGoalBinding.inflate(inflater, container, false)

        binding.icBack.setOnClickListener {
            findNavController().popBackStack()
        }

        binding.beforeGoalList.layoutManager = LinearLayoutManager(requireContext())
        binding.beforeGoalList.adapter = fastAdapter

        itemAdapter.clear()
        repeat(3) {
            itemAdapter.add(GoalInfoData(it))
        }

        binding.progressGoalStatisticLayout.tvGoalEdit.setOnClickListener {
            findNavController().navigate(R.id.goalFragment2)
        }

        val bitmap = getWidgetBitmapCustom(requireContext(), 7)
        binding.progressGoalStatisticLayout.arcProgress.setImageBitmap(bitmap)
        return binding.root
    }

}