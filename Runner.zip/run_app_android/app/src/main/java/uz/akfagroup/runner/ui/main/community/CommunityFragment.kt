package uz.akfagroup.runner.ui.main.community

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.InsetDrawable
import android.os.Bundle
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import uz.akfagroup.runner.databinding.FragmentCommunityBinding


class CommunityFragment : DialogFragment() {

    private var _binding: FragmentCommunityBinding? = null

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        val back = ColorDrawable(Color.TRANSPARENT)
        val inset = InsetDrawable(back, 80)
        dialog?.window?.setBackgroundDrawable(inset)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(
            STYLE_NORMAL,
            android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen
        )
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        setStyle(
            STYLE_NORMAL,
            android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen
        )

        val builder = AlertDialog.Builder(requireContext())
        _binding = FragmentCommunityBinding.inflate(layoutInflater)

        builder.setView(_binding!!.root)
        val communityDialog = builder.create()

        return communityDialog
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}