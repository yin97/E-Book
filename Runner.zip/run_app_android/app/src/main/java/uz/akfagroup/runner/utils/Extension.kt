package uz.akfagroup.runner.utils

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.os.Build
import android.util.TypedValue
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import uz.akfagroup.runner.R
import java.math.RoundingMode
import java.text.DecimalFormat

@SuppressLint("NewApi")
fun getWidgetBitmap(context: Context, progress: Double, max: Double): Bitmap? {
    val percentage = progress * 100 / max
    val df = DecimalFormat("#.#")
    df.roundingMode = RoundingMode.FLOOR
    val process = if (percentage > 100) 100 else if (percentage < 0) 0 else percentage
    val tvProgress =
        if (progress < 0) "0" else if (progress.toInt() in 1..999) "${progress.toInt()}" else
            if (progress.toInt() in 999..999999) "${df.format(progress / 1000f)}k" else
                if (progress.toInt() in 999999..999999999L) "${df.format(progress / 1000000f)}M" else "so long"
    val tvMax = if (max < 0) "0" else if (max.toInt() in 1..999) "${max.toInt()}" else
        if (max.toInt() in 999..999999) "${df.format(max / 1000f)}k" else
            if (max.toInt() in 999999..999999999L) "${df.format(max / 1000000)}M" else "so long"
    val width = 174.dp
    val height = 174.dp
    val stroke = 15.dp
    context.resources.displayMetrics.density

    //Paint for arc stroke.
    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG or Paint.ANTI_ALIAS_FLAG)
    paint.strokeWidth = stroke.toFloat()
    paint.style = Paint.Style.STROKE
    paint.strokeCap = Paint.Cap.ROUND
    //paint.setStrokeJoin(Paint.Join.ROUND);
    //paint.setPathEffect(new CornerPathEffect(10) );

    //Paint for text values.
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    textPaint.textAlign = Paint.Align.CENTER
    val arc = RectF()
    arc[((stroke / 2).toFloat()), ((stroke / 2).toFloat()), ((width - stroke / 2).toFloat())] =
        ((height - stroke / 2).toFloat())
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    paint.color = Color.parseColor("#F3F6FB")
    canvas.drawArc(arc, 135f, 275f, false, paint)

    paint.color = Color.parseColor("#50D890")
    canvas.drawArc(arc, 135f, 2.75f * process.toFloat(), false, paint)

    textPaint.textSize = 20.sp
    paint.color = Color.parseColor("#28303F")
    textPaint.typeface = context.resources.getFont(R.font.gilroy_medium)
    canvas.drawText("Цель", bitmap.width / 2f, (bitmap.height - textPaint.ascent()) / 4, textPaint)

    canvas.drawText(
        "из $tvMax км",
        bitmap.width / 2f,
        (bitmap.height - stroke * 1.5).toFloat(),
        textPaint
    )

    textPaint.textSize = 50.sp
    textPaint.typeface = context.resources.getFont(R.font.gilroy_semi_bold)
    canvas.drawText(
        tvProgress,
        bitmap.width / 2f,
        (bitmap.height - textPaint.ascent()) / 2,
        textPaint
    )

    return bitmap
}

val Int.sp: Float
    get() = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_SP,
        this.toFloat(),
        Resources.getSystem().displayMetrics
    )

val Int.dp: Int
    get() = (this * Resources.getSystem().displayMetrics.density).toInt()


fun getWidgetBitmapCustom(context: Context, percentage: Int): Bitmap? {
    val width = 400
    val height = 400
    val stroke = 30f
    val padding = 5f
    context.resources.displayMetrics.density

    //Paint for arc stroke.
    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG or Paint.ANTI_ALIAS_FLAG)
    paint.strokeWidth = stroke
    paint.style = Paint.Style.STROKE
    paint.strokeCap = Paint.Cap.ROUND
    //paint.setStrokeJoin(Paint.Join.ROUND);
    //paint.setPathEffect(new CornerPathEffect(10) );

    //Paint for text values.
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    textPaint.color = Color.parseColor("#28303F")
    textPaint.textAlign = Paint.Align.CENTER
    val arc = RectF()
    arc[(stroke / 2 + padding), (stroke / 2 + padding), (width - padding - stroke / 2)] =
        (height - padding - stroke / 2)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    //First draw full arc as background.
    paint.color = Color.argb(75, 200, 200, 200)
    canvas.drawArc(arc, 135f, 275f, false, paint)
    //Then draw arc progress with actual value.
    paint.color = Color.parseColor("#50D890")
    canvas.drawArc(arc, 135f, 200f, false, paint)
    textPaint.textSize = 40f
    canvas.drawText("Цель", bitmap.width / 2f, (stroke + padding) * 2.8f, textPaint)
    //Draw text value.
    textPaint.textSize = 100f
    canvas.drawText(
        "$percentage",
        bitmap.width / 2f,
        ((bitmap.height - textPaint.ascent()) / 2) * 0.95f,
        textPaint
    )
    //Draw widget title.
    textPaint.textSize = 40f
    canvas.drawText(
        "из 10 км",
        bitmap.width / 2f,
        (bitmap.height - (stroke + padding)) * 0.95f,
        textPaint
    )
    return bitmap
}

fun Activity.setStatusBarGradiant() {
    val window: Window = this.window
    val background = ContextCompat.getDrawable(this, R.drawable.home_background_circle)
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)

    window.statusBarColor = ContextCompat.getColor(this, android.R.color.transparent)
    window.setBackgroundDrawable(background)
}

interface OnStatusBarSetColor {
    fun onSetStatusBarColor(isSet: Boolean)
}