package uz.akfagroup.runner.ui.main.profile.edit_profile

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentEditProfileBinding

class EditProfileFragment : Fragment() {

    private var _binding: FragmentEditProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEditProfileBinding.inflate(inflater, container, false)

        binding.back.setOnClickListener { findNavController().popBackStack() }
        binding.ibSetting.setOnClickListener { findNavController().navigate(R.id.editProfile_to_settings) }

        binding.tvMale.setOnClickListener { choose(true) }
        binding.tvFemale.setOnClickListener { choose(false) }


        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun choose(i: Boolean) = if (i) {
        binding.bgMale.setCardBackgroundColor(Color.parseColor("#F1FCF4"))
        binding.bgFemale.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.white))
    } else {
        binding.bgMale.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.white))
        binding.bgFemale.setCardBackgroundColor(Color.parseColor("#F1FCF4"))
    }

}