package uz.akfagroup.runner.ui.enter.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentResetBinding

class ResetFragment : Fragment() {

    private lateinit var binding: FragmentResetBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentResetBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.reset_to_code) }

        return binding.root
    }

}