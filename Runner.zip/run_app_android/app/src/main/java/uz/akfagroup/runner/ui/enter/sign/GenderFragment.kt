package uz.akfagroup.runner.ui.enter.sign

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentGenderBinding

class GenderFragment : Fragment() {

    private lateinit var binding: FragmentGenderBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentGenderBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.gender_to_weight) }

        binding.maleButton.setOnClickListener { choose(true) }
        binding.femaleButton.setOnClickListener { choose(false) }

        return binding.root
    }

    private fun choose(i: Boolean) {
        if (i){
            binding.maleBackground.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.femaleBackground.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
            binding.maleButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            binding.femaleButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        }
        else{
            binding.maleBackground.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
            binding.femaleBackground.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.main))
            binding.maleButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
            binding.femaleButton.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
        }
    }

}