package uz.akfagroup.runner.ui.main.progress.models

import android.view.View
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.items.AbstractItem
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.ItemTrainingBinding

data class TrainingData(
    val id: Int,
    val image: Int? = null,
    val distance: Int? = null,
    val time: String? = null,
    val point: Int? = null,
    val date: String? = null
) : AbstractItem<TrainingData.VH>() {

    override var identifier: Long
        get() = id.toLong()
        set(value) {}

    inner class VH(itemView: View) : FastAdapter.ViewHolder<TrainingData>(itemView) {
        override fun bindView(item: TrainingData, payloads: List<Any>) {
            val binding = ItemTrainingBinding.bind(itemView)
            binding.tvDistance.text = itemView.context.resources.getString(
                R.string.text_training_distance,
                item.distance
            )
            binding.tvPoint.text = itemView.context.resources.getString(
                R.string.text_training_points,
                item.point
            )
        }

        override fun unbindView(item: TrainingData) {

        }

    }

    override val type: Int
        get() = 0
    override val layoutRes: Int
        get() = R.layout.item_training

    override fun getViewHolder(v: View): VH = VH(v)
}