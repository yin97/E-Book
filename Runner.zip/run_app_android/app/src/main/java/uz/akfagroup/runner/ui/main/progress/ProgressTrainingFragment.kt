package uz.akfagroup.runner.ui.main.progress

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.GenericFastAdapter
import com.mikepenz.fastadapter.GenericItem
import com.mikepenz.fastadapter.adapters.GenericItemAdapter
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration
import uz.akfagroup.runner.databinding.FragmentProgressTrainingBinding
import uz.akfagroup.runner.ui.main.progress.adapter.StickyHeaderAdapter
import uz.akfagroup.runner.ui.main.progress.models.TrainingData


class ProgressTrainingFragment : Fragment() {

    private var _binding: FragmentProgressTrainingBinding? = null
    private val binding get() = _binding!!
    private var itemAdapter = GenericItemAdapter()
    private var fastAdapter: GenericFastAdapter = FastAdapter.with(itemAdapter)
    private val stickyHeaderAdapter = StickyHeaderAdapter<GenericItem>()

    private var monthArray = arrayListOf(
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentProgressTrainingBinding.inflate(inflater, container, false)

        val arrayAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, monthArray)
        binding.spinnerMonth.adapter = arrayAdapter

        binding.trainingList.layoutManager = LinearLayoutManager(requireContext())
        binding.trainingList.adapter = stickyHeaderAdapter.wrap(fastAdapter)
        binding.trainingList.itemAnimator = DefaultItemAnimator()

        val decoration = StickyRecyclerHeadersDecoration(stickyHeaderAdapter)
        binding.trainingList.addItemDecoration(decoration)

        binding.icBack.setOnClickListener {
            findNavController().popBackStack()
        }

        repeat(30) { id ->
            itemAdapter.add(TrainingData(id = id, distance = 10, point = 500))
        }

        return binding.root
    }

}