package uz.akfagroup.runner.ui.enter.sign

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentCompletedBinding
import uz.akfagroup.runner.utils.getWidgetBitmap

class CompletedFragment : Fragment() {

    private lateinit var binding: FragmentCompletedBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCompletedBinding.inflate(inflater, container, false)

        binding.arcProgress.setImageBitmap(getWidgetBitmap(requireContext(), 55.0, 99.0))

        binding.button.setOnClickListener { findNavController().navigate(R.id.completed_to_goal) }

        return binding.root
    }

}