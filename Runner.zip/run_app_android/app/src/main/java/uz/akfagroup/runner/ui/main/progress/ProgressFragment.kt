package uz.akfagroup.runner.ui.main.progress

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.adapters.ItemAdapter
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentProgressBinding
import uz.akfagroup.runner.ui.main.progress.models.StatisticData
import uz.akfagroup.runner.ui.main.progress.models.TrainingData
import uz.akfagroup.runner.utils.SpacesItemDecoration
import uz.akfagroup.runner.utils.getWidgetBitmapCustom
import kotlin.random.Random


class ProgressFragment : Fragment() {

    private var _binding: FragmentProgressBinding? = null
    private val binding get() = _binding!!

    private val itemAdapter = ItemAdapter<TrainingData>()
    private val fastAdapter = FastAdapter.with(itemAdapter)

    private val statisticItemAdapter = ItemAdapter<StatisticData>()
    private val statisticFastAdapter = FastAdapter.with(statisticItemAdapter)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProgressBinding.inflate(layoutInflater, container, false)

        binding.progressTrainingLayout.apply {
            trainingList.layoutManager = LinearLayoutManager(requireContext())
            trainingList.adapter = fastAdapter
        }

        val layoutManager = GridLayoutManager(requireContext(), 7)
        binding.progressWeeklyLayout.apply {

            weeklyStatisticList.apply {
                this.layoutManager = layoutManager
                itemAnimator = DefaultItemAnimator()
                adapter = statisticFastAdapter

            }

            val scale = resources.displayMetrics.density
            val marginPixels = (16 * scale + 0.5f).toInt()
            weeklyStatisticList.addItemDecoration(SpacesItemDecoration(marginPixels, true, 7))
        }

        val bitmap = getWidgetBitmapCustom(requireContext(), 7)
        binding.progressGoalLayout.arcProgress.setImageBitmap(bitmap)

        itemAdapter.clear()
        statisticItemAdapter.clear()


        repeat(2) {
            itemAdapter.add(
                TrainingData(
                    id = it,
                    distance = (it * 10 + 2),
                    point = (it * 100 + 22)
                )
            )
        }

        binding.progressTrainingLayout.tvMore.setOnClickListener {
            findNavController().navigate(R.id.progress_training_fragment)
        }

        binding.progressWeeklyLayout.tvMore.setOnClickListener {
            findNavController().navigate(R.id.progressStatisticFragment)
        }

        binding.progressGoalLayout.tvMore.setOnClickListener {
            findNavController().navigate(R.id.progressGoalFragment)
        }

        statisticItemAdapter.add(StatisticData(0, progress = 60, day = "П"))
        statisticItemAdapter.add(StatisticData(1, progress = 12, day = "В"))
        statisticItemAdapter.add(StatisticData(2, progress = 20, day = "С"))
        statisticItemAdapter.add(StatisticData(3, progress = 40, day = "Ч"))
        statisticItemAdapter.add(StatisticData(4, progress = 80, day = "П"))
        statisticItemAdapter.add(StatisticData(5, progress = 100, day = "С"))
        statisticItemAdapter.add(StatisticData(6, progress = 30, day = "В"))

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}