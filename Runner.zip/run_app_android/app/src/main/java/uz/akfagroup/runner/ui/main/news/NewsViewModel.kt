package uz.akfagroup.runner.ui.main.news

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import uz.akfagroup.runner.R
import uz.akfagroup.runner.ui.main.news.model.News

class NewsViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text

    val list = MutableLiveData<ArrayList<News>>()

    fun addNews() {
        val news = ArrayList<News>()
        news.add(News(0, R.drawable.image1))
        news.add(News(1, R.drawable.image2))
        list.postValue(news)
    }
}