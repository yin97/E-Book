package uz.akfagroup.runner.ui.main.training

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentTrainingBinding
import uz.akfagroup.runner.utils.getWidgetBitmap
import uz.akfagroup.runner.utils.getWidgetBitmapCustom


class TrainingFragment : Fragment() {

    private var _binding: FragmentTrainingBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val trainingViewModel =
            ViewModelProvider(this).get(TrainingViewModel::class.java)

        _binding = FragmentTrainingBinding.inflate(inflater, container, false)
        val root: View = binding.root


        val bitmap = getWidgetBitmapCustom(requireContext(),70)
        binding.arcProgress.setImageBitmap(bitmap)

        binding.btnPlay.setOnClickListener {
            start()
        }

        binding.btnPause.setOnClickListener {
            pause()
        }

        binding.btnStop.setOnClickListener {
            stop()
        }

        return root
    }

    fun start(){
        binding.btnPlay.visibility = View.GONE
        binding.btnPause.visibility = View.VISIBLE
        binding.btnStop.visibility = View.VISIBLE
    }

    fun pause(){
        binding.btnPlay.visibility = View.VISIBLE
        binding.btnPause.visibility = View.GONE
        binding.btnStop.visibility = View.VISIBLE
    }

    fun stop(){
        binding.btnPlay.visibility = View.VISIBLE
        binding.btnPause.visibility = View.GONE
        binding.btnStop.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}