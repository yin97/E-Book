package uz.akfagroup.runner.ui.enter.sign

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentLifestyleBinding

class LifestyleFragment : Fragment() {

    private lateinit var binding: FragmentLifestyleBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLifestyleBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.lifestyle_to_completed) }

        binding.tvActive.setOnClickListener { choose(1) }
        binding.tvMobile.setOnClickListener { choose(2) }
        binding.tvSedentary.setOnClickListener { choose(3) }

        return binding.root
    }

    private fun choose(i: Int) {

        binding.tvActive.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        binding.tvMobile.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        binding.tvSedentary.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        binding.cvActive.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
        binding.cvMobile.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
        binding.cvSedentary.setCardBackgroundColor(Color.parseColor("#F1F5F9"))

        when (i) {
            1 -> {
                binding.cvActive.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.tvActive.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            }
            2 -> {
                binding.cvMobile.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.tvMobile.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            }
            else -> {
                binding.cvSedentary.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.main))
                binding.tvSedentary.setTextColor(ContextCompat.getColor(requireContext(), R.color.white))
            }
        }

    }

}