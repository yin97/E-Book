package uz.akfagroup.runner.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import uz.akfagroup.runner.OnboardActivity
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.ActivityMainBinding
import uz.akfagroup.runner.utils.SharedPrefs
import uz.akfagroup.runner.utils.setStatusBarGradiant

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNavigation()

        if (!SharedPrefs(this).isNotFirstTime) {
            SharedPrefs(this).setFirstTime(true)
            startActivity(Intent(this, OnboardActivity::class.java))
            finish()
        }

        setStatusBarGradiant()
    }

    private fun setupBottomNavigation() {
        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)

        navView.setupWithNavController(navController)
    }
}