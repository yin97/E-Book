package uz.akfagroup.runner.ui.main.news.model


data class News(
    val id: Int,
    val image:Int
)