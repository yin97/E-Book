package uz.akfagroup.runner.ui.enter.onboard

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.FragmentLanguageBinding

class LanguageFragment : Fragment() {

    private lateinit var binding: FragmentLanguageBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentLanguageBinding.inflate(inflater, container, false)

        binding.button.setOnClickListener { findNavController().navigate(R.id.lang_to_runner) }

        binding.uzButton.setOnClickListener { choose(1) }
        binding.ruButton.setOnClickListener { choose(2) }
        binding.enButton.setOnClickListener { choose(3) }

        return binding.root
    }

    private fun choose(i: Int) {
        binding.uzBackground.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
        binding.ruBackground.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
        binding.enBackground.setCardBackgroundColor(Color.parseColor("#F1F5F9"))
        when (i) {
            1 -> binding.uzBackground.setCardBackgroundColor(Color.parseColor("#9BD7DF"))
            2 -> binding.ruBackground.setCardBackgroundColor(Color.parseColor("#9BD7DF"))
            else -> binding.enBackground.setCardBackgroundColor(Color.parseColor("#9BD7DF"))
        }
    }

}