package uz.akfagroup.runner.ui.main.progress.models

import android.view.View
import com.mikepenz.fastadapter.FastAdapter
import com.mikepenz.fastadapter.items.AbstractItem
import uz.akfagroup.runner.R
import uz.akfagroup.runner.databinding.ItemPeriodBinding

data class PeriodData(
    val id: Int,
    val name: String
) : AbstractItem<PeriodData.PeriodViewHolder>() {

    override var identifier: Long
        get() = id.toLong()
        set(value) {}

    inner class PeriodViewHolder(itemView: View) : FastAdapter.ViewHolder<PeriodData>(itemView) {
        override fun bindView(item: PeriodData, payloads: List<Any>) {
            val binding = ItemPeriodBinding.bind(itemView)

            binding.tvPeriod.text = item.name
        }

        override fun unbindView(item: PeriodData) {

        }

    }

    override val type: Int
        get() = 0
    override val layoutRes: Int
        get() = R.layout.item_period

    override fun getViewHolder(v: View): PeriodViewHolder = PeriodViewHolder(v)
}