package uz.akfagroup.runner.ui.main.news

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import uz.akfagroup.runner.databinding.ItemNewsBinding
import uz.akfagroup.runner.ui.main.news.model.News
import java.util.*


class NewsAdapter(
    private val context: Context
) :
    RecyclerView.Adapter<NewsAdapter.ViewHolder>() {

    var items: ArrayList<News> = arrayListOf()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    class ViewHolder(private val binding: ItemNewsBinding) :
        RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n", "SimpleDateFormat")
        fun bind(
            context: Context,
            item: News,
        ) {
            var expand = true
            binding.root.setOnClickListener {
                if (expand) {
                    binding.txtExpand.visibility = View.VISIBLE
                    binding.btnExpand.rotation = 180f
                } else {
                    binding.txtExpand.visibility = View.GONE
                    binding.btnExpand.rotation = 0f
                }
                expand = !expand
            }

            Glide.with(context).load(item.image).into(binding.imgNotify)

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ViewHolder(ItemNewsBinding.inflate(LayoutInflater.from(context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
            holder.bind(context, items[position])

    override fun getItemCount() = items.size

}

